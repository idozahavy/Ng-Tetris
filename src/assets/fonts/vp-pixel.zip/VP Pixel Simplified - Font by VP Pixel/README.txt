VP Pixel is a font family of eight classic pixel styles that feel both retro and futurist.
All styles include an extensive character set with support for advanced OpenType features.


The font you have downloaded is a DEMO version free for personal use. It is fully functional but limited to only one style and ninety basic characters.


IF YOU WANT TO USE THIS FONT COMMERCIALLY
or unlock all of its 855 characters, advanced OpenType features, and other styles - please purchase it on Fontspring at http://fontspring.com/fonts/vp-type/vp-pixel or on MyFonts at https://www.myfonts.com/fonts/val-kalinic/vp-pixel. Both links include inexpensive options for Webfont, App, eBook, Server, and any other licenses you may need.


Thank you,
VP Type